;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "1.2.1"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "a75f4fe69abc0e8b15c739e3d07bc237a974e052"
  :revdesc "1.2.1-0-ga75f4fe69abc"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
