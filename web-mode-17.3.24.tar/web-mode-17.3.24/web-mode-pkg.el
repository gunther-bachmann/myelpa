;; Generated package description from web-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "web-mode" "17.3.24" "major mode for editing web templates" '((emacs "24.3.1")) :commit "aeee2d4c82a791ff69657c1413873bf9265544df" :maintainer '("François-Xavier Bois" . "fxbois@gmail.com") :keywords '("languages") :url "https://web-mode.org")
