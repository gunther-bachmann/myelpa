;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "1.0.3"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "99004e3a2539686e7d714ef4f7290726f3ad6fe3"
  :revdesc "1.0.3-0-g99004e3a2539"
  :keywords '("convenience"))
