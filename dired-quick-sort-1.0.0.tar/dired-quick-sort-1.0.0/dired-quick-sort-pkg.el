;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-quick-sort" "1.0.0"
  "Persistent quick sorting of Dired buffers in various ways."
  '((emacs "28"))
  :url "https://gitlab.com/xuhdev/dired-quick-sort"
  :commit "0d6d2a6f6d3e472bafb9da69094c963d9413818c"
  :revdesc "0d6d2a6f6d3e"
  :keywords '("convenience" "files")
  :authors '(("Hong Xu" . "hong@topbug.net"))
  :maintainers '(("Hong Xu" . "hong@topbug.net")))
