;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "1.8.1"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "3b8cb569409ccbef7e9e955aefcd550c4be3e607"
  :revdesc "3b8cb569409c"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
