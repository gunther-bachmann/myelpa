;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-sudoedit" "1.1.2"
  "Auto sudo edit by tramp."
  '((emacs "26.1")
    (f     "0.19.0"))
  :url "https://github.com/ncaq/auto-sudoedit"
  :commit "b792e82a2e55be18c5fe945213325d6c84a2813c"
  :revdesc "v1.1.2-0-gb792e82a2e55"
  :authors '(("ncaq" . "ncaq@ncaq.net"))
  :maintainers '(("ncaq" . "ncaq@ncaq.net")))
