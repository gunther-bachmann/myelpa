;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultra-scroll" "0.6.2"
  "Fast and smooth scrolling."
  '((emacs "29.1"))
  :url "https://github.com/jdtsmith/ultra-scroll"
  :commit "f38653053b5c9bbe8dbcb6b2236ab8997fc2f9bb"
  :revdesc "f38653053b5c"
  :keywords '("convenience"))
