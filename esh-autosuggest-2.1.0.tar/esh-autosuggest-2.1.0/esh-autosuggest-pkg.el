;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esh-autosuggest" "2.1.0"
  "History autosuggestions for eshell."
  '((emacs   "24.4")
    (company "0.9.4"))
  :url "http://sr.ht/~dieggsy/esh-autosuggest"
  :commit "1017a4992c086d6d0924572561879af1ac1d8c03"
  :revdesc "2.1.0-0-g1017a4992c08"
  :keywords '("completion" "company" "matching" "convenience" "abbrev")
  :authors '(("Diego A. Mundo" . "dieggsy@pm.me"))
  :maintainers '(("Diego A. Mundo" . "dieggsy@pm.me")))
