;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20250907.808"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "eb89b2a2bb21e4eca3891d0723da68768cd386d8"
  :revdesc "eb89b2a2bb21"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
