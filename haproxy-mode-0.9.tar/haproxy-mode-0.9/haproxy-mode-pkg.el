;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haproxy-mode" "0.9"
  "Major mode for editing HAProxy config files."
  '((emacs "24.3"))
  :url "https://github.com/port19x/haproxy-mode"
  :commit "eafb1144751493c33dc005a317236ec3e84aeb07"
  :revdesc "eafb11447514"
  :keywords '("haproxy" "languages" "tools")
  :authors '(("port19" . "port19@port19.xyz"))
  :maintainers '(("port19" . "port19@port19.xyz")))
