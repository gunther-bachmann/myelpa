;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20250921.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "b8f914d1d5f0b0343e44a50a44c2a0520a90628a"
  :revdesc "b8f914d1d5f0"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
