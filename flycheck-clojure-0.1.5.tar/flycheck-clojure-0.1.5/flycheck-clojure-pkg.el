;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-clojure" "0.1.5"
  "Flycheck: Clojure support."
  '((cider     "0.8.1")
    (flycheck  "0.22-cvs1")
    (let-alist "1.0.1")
    (emacs     "24"))
  :url "https://github.com/clojure-emacs/squiggly-clojure"
  :commit "fc0f1473c85b5287c8a62c1eee86894c98fbb84c"
  :revdesc "0.1.5-0-gfc0f1473c85b"
  :authors '(("Peter Fraenkel" . "pnf@podsnap.com")
             ("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Peter Fraenkel" . "pnf@podsnap.com")))
