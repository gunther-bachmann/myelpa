;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260215.907"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "1fdc8b07baf82ad57cbede472d999fd6e5223042"
  :revdesc "1fdc8b07baf8"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
