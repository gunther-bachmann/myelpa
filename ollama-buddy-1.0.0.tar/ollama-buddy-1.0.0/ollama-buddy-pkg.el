;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "1.0.0"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "829bfc32aa3cb28b6f2b60f151cfe1b0b2f761f0"
  :revdesc "829bfc32aa3c"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
