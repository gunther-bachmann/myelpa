;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pretty-hydra" "0.2.2"
  "A macro for creating nice-looking hydras."
  '((hydra           "0.15.0")
    (s               "1.12.0")
    (dash            "2.15.0")
    (dash-functional "1.2.0")
    (emacs           "24"))
  :url "https://github.com/jerrypnz/major-mode-hydra.el"
  :commit "bba876b86f0b80495004bf185b2b1f6083a1ff3a"
  :revdesc "0.2.2-0-gbba876b86f0b"
  :authors '(("Jerry Peng" . "pr2jerry@gmail.com"))
  :maintainers '(("Jerry Peng" . "pr2jerry@gmail.com")))
