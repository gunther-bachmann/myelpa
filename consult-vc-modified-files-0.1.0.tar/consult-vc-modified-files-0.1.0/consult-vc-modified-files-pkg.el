;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-vc-modified-files" "0.1.0"
  "Show git modified files in a vc project with consult."
  '((emacs   "28.1")
    (consult "0.9"))
  :url "https://github.com/chmouel/consult-vc-modified-files"
  :commit "e73aa635cfe454e62bbaca0fd8bbdc0a30946ee6"
  :revdesc "e73aa635cfe4"
  :keywords '("vc" "convenience")
  :authors '(("Chmouel Boudjnah" . "chmouel@chmouel.com"))
  :maintainers '(("Chmouel Boudjnah" . "chmouel@chmouel.com")))
