;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "html2org" "20170418.501"
  "Convert html to org format text."
  '((emacs "24.4"))
  :url "http://github.com/lujun9972/html2org.el"
  :commit "6904aed40259ad8afccff079ebd8a07bff319ebc"
  :revdesc "6904aed40259"
  :keywords '("convenience" "html" "org")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
