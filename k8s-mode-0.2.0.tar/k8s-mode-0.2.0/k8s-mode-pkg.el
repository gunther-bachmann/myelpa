;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "k8s-mode" "0.2.0"
  "Major mode for Kubernetes configuration file."
  '((emacs     "24.3")
    (yaml-mode "0.0.10"))
  :url "https://github.com/TxGVNN/emacs-k8s-mode"
  :commit "430e9d698f1411efe3f8f2bb4c8f8857e0321a8d"
  :revdesc "430e9d698f14"
  :authors '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers '(("Giap Tran" . "txgvnn@gmail.com")))
