;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "0.3"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "c6e8cc6753d3b880b09a6e28f244ada48debfb2b"
  :revdesc "c6e8cc6753d3"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
