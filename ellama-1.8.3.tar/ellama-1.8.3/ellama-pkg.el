;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "1.8.3"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "2c20a9a0eed24da9a40e995c610d036ffa61157d"
  :revdesc "2c20a9a0eed2"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
