;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "1.1.2"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "c8475c2445913765ed5b9928045e62345ee866c6"
  :revdesc "1.1.2-0-gc8475c244591"
  :keywords '("convenience"))
