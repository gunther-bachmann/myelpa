;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "0.2"
  "Better manage line numbers in your org-mode links."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "8b2e05682efb88d35f8342795d6e49c4f2549687"
  :revdesc "8b2e05682efb"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
