;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browse-at-remote" "0.14.0"
  "Open github/gitlab/bitbucket/stash/gist/phab/sourcehut page from Emacs."
  '((f      "0.17.2")
    (s      "1.9.0")
    (cl-lib "0.5"))
  :url "https://github.com/rmuslimov/browse-at-remote"
  :commit "771a3079e27f397d2f5a9470b945980fa68ee048"
  :revdesc "0.14.0-0-g771a3079e27f"
  :keywords '("github" "gitlab" "bitbucket" "gist" "stash" "phabricator" "sourcehut" "pagure")
  :authors '(("Rustem Muslimov" . "r.muslimov@gmail.com"))
  :maintainers '(("Rustem Muslimov" . "r.muslimov@gmail.com")))
