(ns foo
  (:require
   [clj-http.client :as client]))
