;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-view-mode" "20251211.720"
  "Read-only viewer with less markup clutter in org mode files."
  '((emacs "25.1"))
  :url "https://github.com/amno1/org-view-mode"
  :commit "8082b9e9841d1a2e947ab7bebbdf0c49c4b64cdf"
  :revdesc "8082b9e9841d"
  :keywords '("convenience" "outlines" "tools")
  :authors '(("Arthur Miller" . "arthur.miller@live.com"))
  :maintainers '(("Arthur Miller" . "arthur.miller@live.com")))
