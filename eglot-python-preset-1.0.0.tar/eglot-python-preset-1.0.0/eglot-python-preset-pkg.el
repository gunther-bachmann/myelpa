;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-python-preset" "1.0.0"
  "Eglot preset for Python."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-python-preset"
  :commit "719b3aa8fd47aec6c1c3094e2468f41b9d588b09"
  :revdesc "719b3aa8fd47"
  :keywords '("python" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
