;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-line-preview" "0.2.0"
  "Preview line when executing `goto-line` command."
  '((emacs "25"))
  :url "https://github.com/emacs-vs/goto-line-preview"
  :commit "f835428addbadc8af782b5ea511103c5f10b6dc5"
  :revdesc "f835428addba"
  :keywords '("convenience" "line" "navigation")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
