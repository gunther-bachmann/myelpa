;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "2.5"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/jinx"
  :commit "a678be8cf0888947789a10a493c8b1c3a7066f52"
  :revdesc "a678be8cf088"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
