;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difftastic" "1.0.0"
  "Wrapper for difftastic."
  '((emacs     "28.1")
    (compat    "29.1.4.2")
    (magit     "4.0.0")
    (transient "0.4.0"))
  :url "https://github.com/pkryger/difftastic.el"
  :commit "b33554a22c637f147d07c15fa9539c72bcfcfca0"
  :revdesc "v1.0.0-0-gb33554a22c63"
  :keywords '("tools" "diff")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
