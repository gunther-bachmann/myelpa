;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ast-grep" "0.1.2"
  "Search code using ast-grep with completing-read interface."
  '((emacs "28.1"))
  :url "https://github.com/sunskyxh/ast-grep.el"
  :commit "cb9e9c453abaf7852dda84707152e52ad7f9e910"
  :revdesc "cb9e9c453aba"
  :keywords '("tools" "matching")
  :authors '(("SunskyxXH" . "sunskyxh@gmail.com"))
  :maintainers '(("SunskyxXH" . "sunskyxh@gmail.com")))
