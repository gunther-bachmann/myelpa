Show current command and its key in the mode line
=================================================

This package provides two modes that display the current command
and its key or mouse binding, and update the displayed information
once another command is invoked.

`keycast-mode` displays the command and event in the mode-line and
`keycast-log-mode` displays them in a dedicated frame.

![screenshot](http://readme.emacsair.me/keycast.png)
