;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "0.11.1"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "784b00017262260c2c718c98af98f16a2cc7bfdd"
  :revdesc "784b00017262")
