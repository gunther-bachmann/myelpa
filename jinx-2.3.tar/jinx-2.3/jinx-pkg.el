;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "2.3"
  "Enchanted Spell Checker."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/jinx"
  :commit "214d98c18c01897eab108a880b18aa3b64632a03"
  :revdesc "214d98c18c01"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
