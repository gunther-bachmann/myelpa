;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bm" "202506"
  "Visible bookmarks in buffer."
  ()
  :url "https://github.com/joodland/bm"
  :commit "1fefbc46d10d5398ecca93aa18ef1af3fc1f44b4"
  :revdesc "1fefbc46d10d"
  :keywords '("bookmark" "highlight" "faces" "persistent")
  :authors '(("Jo Odland" . "jo.odlandgmail.com"))
  :maintainers '(("Jo Odland" . "jo.odlandgmail.com")))
