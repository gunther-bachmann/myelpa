;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "1.10.11"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "c491bf4c5b6449751a55afa6772c8cdb0e167a41"
  :revdesc "c491bf4c5b64"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
