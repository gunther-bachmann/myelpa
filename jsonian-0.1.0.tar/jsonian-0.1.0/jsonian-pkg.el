;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsonian" "0.1.0"
  "A major mode for editing JSON files."
  '((emacs "27.1"))
  :url "https://github.com/iwahbe/jsonian"
  :commit "43ab410a017f01bff89f83de3b450da46691e6a2"
  :revdesc "43ab410a017f")
