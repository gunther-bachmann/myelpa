;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eff" "0.2"
  "Show symbols in Executable File Formats."
  '((emacs "28"))
  :url "https://github.com/oxidase/eff"
  :commit "b8ce5d82dc2ef4df912b2b0cbe79e20b455ebd84"
  :revdesc "b8ce5d82dc2e"
  :keywords '("elf" "readelf" "convenience"))
