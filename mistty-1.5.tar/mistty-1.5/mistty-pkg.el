;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "1.5"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "e12c6af9894d6dbfd127047663275c763cab4e89"
  :revdesc "e12c6af9894d"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
