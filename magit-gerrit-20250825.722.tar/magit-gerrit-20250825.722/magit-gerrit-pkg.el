;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gerrit" "20250825.722"
  "Magit plugin for Gerrit Code Review."
  '((emacs     "25.1")
    (magit     "2.90.1")
    (transient "0.3.0"))
  :url "https://github.com/emacsorphanage/magit-gerrit"
  :commit "37a4774c3cc401f849d57aaa2c105ca401f9983c"
  :revdesc "37a4774c3cc4"
  :authors '(("Brian Fransioli" . "assem@terranpro.org"))
  :maintainers '(("Brian Fransioli" . "assem@terranpro.org")))
