;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "0.5.5"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "24.4")
    (dash  "2.9.0"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "d345e2198d6b80c01d627af7aa44ab25b9ed8eda"
  :revdesc "d345e2198d6b"
  :keywords '("programming"))
