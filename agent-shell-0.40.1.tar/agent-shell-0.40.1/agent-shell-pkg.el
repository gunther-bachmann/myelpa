;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.40.1"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "114168642b93546097ef3b36c116f397e7a551a7"
  :revdesc "114168642b93")
