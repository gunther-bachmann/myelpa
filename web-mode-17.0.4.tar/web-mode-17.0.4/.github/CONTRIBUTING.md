# Contributing to Web-Mode

Things that might be useful in your report

* an accurate description of the issue
* an example on gist (a screenshot of the code is a bad idea because it can not be copy/paste)
* the output of ```M-x web-mode-debug```
* lines in the * *Messages* * buffer related to the issue (if they exist)
* a screenshot (if needed)
