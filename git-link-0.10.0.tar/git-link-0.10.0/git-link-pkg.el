;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-link" "0.10.0"
  "Get the GitHub/Bitbucket/GitLab URL for a buffer location."
  '((emacs "24.3"))
  :url "http://github.com/sshaw/git-link"
  :commit "67b02cf0df4e789771f2344b4dd77c85334a0f9f"
  :revdesc "67b02cf0df4e"
  :keywords '("git" "vc" "github" "bitbucket" "gitlab" "sourcehut" "aws" "azure" "convenience")
  :authors '(("Skye Shaw" . "skye.shaw@gmail.com"))
  :maintainers '(("Skye Shaw" . "skye.shaw@gmail.com")))
