;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redtick" "0.1.1"
  "Smallest pomodoro timer (1 char)."
  '((emacs "24"))
  :url "http://github.com/ferfebles/redtick"
  :commit "14e3a07c229d1f660ca5129d6e8a52a8c68db94d"
  :revdesc "14e3a07c229d"
  :keywords '("pomodoro" "timer"))
