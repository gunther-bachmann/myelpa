;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "3.5"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "f046ebb91473830a174fb54e3dc8119bbe7e0c7c"
  :revdesc "3.5-0-gf046ebb91473"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
