;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-inline" "20250715.1251"
  "Display Flycheck errors inline."
  '((emacs    "25.1")
    (flycheck "32"))
  :url "https://github.com/flycheck/flycheck-inline"
  :commit "2cd7c0a67ad46495b818c3789a6c6a1b5af88011"
  :revdesc "2cd7c0a67ad4"
  :keywords '("tools" "convenience"))
