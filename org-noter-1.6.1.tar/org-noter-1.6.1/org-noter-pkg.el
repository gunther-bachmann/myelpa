;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-noter" "1.6.1"
  "A synchronized, Org-mode, document annotator."
  '((emacs  "24.4")
    (cl-lib "0.6")
    (org    "9.4"))
  :url "https://github.com/org-noter/org-noter"
  :commit "284b425f7275ca04bab0f691dfe284a4e059288c"
  :revdesc "284b425f7275"
  :keywords '("lisp" "pdf" "interleave" "annotate" "external" "sync" "notes" "documents" "org-mode")
  :authors '(("Gonçalo Santos" . "in@bsentia")
             ("Maintainer Dmitry M" . "dmitrym@gmail.com"))
  :maintainers '(("Peter Mao" . "peter.mao@gmail.com")
                 ("Dmitry M" . "dmitrym@gmail.com")))
