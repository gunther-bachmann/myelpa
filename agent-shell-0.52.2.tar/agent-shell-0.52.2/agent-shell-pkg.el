;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.52.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "2e288326f43397008b04d3da0724acf5afab9283"
  :revdesc "2e288326f433")
