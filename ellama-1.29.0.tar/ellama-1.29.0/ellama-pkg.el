;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "1.29.0"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.31.1")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "09857e5d2ec8a7bfc68b510a2a6afce2b165566b"
  :revdesc "09857e5d2ec8"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
