;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "deadgrep" "0.13"
  "Fast, friendly searching with ripgrep."
  '((emacs   "25.1")
    (dash    "2.12.0")
    (s       "1.11.0")
    (spinner "1.7.3"))
  :url "https://github.com/Wilfred/deadgrep"
  :commit "ad7ddfbce9d1b665281c2ec6ea48644602925d30"
  :revdesc "ad7ddfbce9d1"
  :keywords '("tools")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
