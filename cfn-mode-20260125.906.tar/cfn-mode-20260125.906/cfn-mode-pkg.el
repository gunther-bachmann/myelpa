;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260125.906"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "a8fc3f128497ba1061630f9076019ed68d1d41bf"
  :revdesc "a8fc3f128497"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
