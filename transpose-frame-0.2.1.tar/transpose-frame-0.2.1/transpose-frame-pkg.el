;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transpose-frame" "0.2.1"
  "Transpose windows arrangement in a frame."
  ()
  :url "https://github.com/emacsorphanage/transpose-frame"
  :commit "7b7f8a1582436749a57ebbba6ead716b5a0edddc"
  :revdesc "v0.2.1-0-g7b7f8a158243"
  :keywords '("window"))
