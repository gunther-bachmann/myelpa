;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orderless" "1.6"
  "Completion style for matching regexps in any order."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/oantolin/orderless"
  :commit "6e3a09d6026fe7d7d5a3caf9a3d777cc9841fe80"
  :revdesc "1.6-0-g6e3a09d6026f"
  :keywords '("matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
