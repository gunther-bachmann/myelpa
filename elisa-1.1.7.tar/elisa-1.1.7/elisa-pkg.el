;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisa" "1.1.7"
  "Emacs Lisp Information System Assistant."
  '((emacs  "29.2")
    (ellama "0.11.2")
    (llm    "0.18.1")
    (async  "1.9.8")
    (plz    "0.9"))
  :url "http://github.com/s-kostyaev/elisa"
  :commit "b655b59d371639d357dcabe48f1c2cd1694ee8de"
  :revdesc "b655b59d3716"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
