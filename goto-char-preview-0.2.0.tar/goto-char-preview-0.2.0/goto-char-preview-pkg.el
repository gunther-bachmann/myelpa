;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-char-preview" "0.2.0"
  "Preview character when executing `goto-char` command."
  '((emacs "24.3"))
  :url "https://github.com/emacs-vs/goto-char-preview"
  :commit "13c9ab10b0a4f5be0b22158f6437a535a3f36240"
  :revdesc "13c9ab10b0a4"
  :keywords '("convenience" "character" "navigation")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
