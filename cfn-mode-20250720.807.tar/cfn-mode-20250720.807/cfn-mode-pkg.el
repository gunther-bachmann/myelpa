;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20250720.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "7cb7e4d30a863bd9fa5b11fba72925ea1809ec66"
  :revdesc "7cb7e4d30a86"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
