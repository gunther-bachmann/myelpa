;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-eglot" "20260221.2040"
  "Flycheck support for eglot."
  '((emacs    "28.1")
    (eglot    "1.9")
    (flycheck "32"))
  :url "https://github.com/flycheck/flycheck-eglot"
  :commit "c34f61984d523ffba13a1aae3d0003de742d8b8b"
  :revdesc "c34f61984d52"
  :keywords '("convenience" "language" "tools")
  :authors '(("Sergey Firsov" . "intramurz@gmail.com"))
  :maintainers '(("Sergey Firsov" . "intramurz@gmail.com")))
