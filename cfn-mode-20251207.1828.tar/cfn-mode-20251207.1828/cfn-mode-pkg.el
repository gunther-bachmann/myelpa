;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20251207.1828"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "82fc7cc9932a9e2d9ca96d3d307d06c2930d7070"
  :revdesc "82fc7cc9932a"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
