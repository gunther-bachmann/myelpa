;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gerrit" "0.4"
  "Magit plugin for Gerrit Code Review."
  '((emacs     "25.1")
    (magit     "2.90.1")
    (transient "0.3.0"))
  :url "https://github.com/terranpro/magit-gerrit"
  :commit "4f6212e1b19d65e422da1a3c8f54a1a5ab396a2c"
  :revdesc "v0.4-0-g4f6212e1b19d"
  :authors '(("Brian Fransioli" . "assem@terranpro.org"))
  :maintainers '(("Brian Fransioli" . "assem@terranpro.org")))
