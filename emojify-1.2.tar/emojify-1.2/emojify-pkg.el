;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emojify" "1.2"
  "Display emojis in Emacs."
  '((seq   "1.11")
    (ht    "2.0")
    (emacs "24.3"))
  :url "https://github.com/iqbalansari/emacs-emojify"
  :commit "302d16e9bac72faf94984e0c48ecd0e4b8d66738"
  :revdesc "302d16e9bac7"
  :keywords '("multimedia" "convenience")
  :authors '(("Iqbal Ansari" . "iqbalansari02@yahoo.com"))
  :maintainers '(("Iqbal Ansari" . "iqbalansari02@yahoo.com")))
