;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20260117.1631"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "14b9fb4b48a08806836bc93f09cf44565aa9f152"
  :revdesc "14b9fb4b48a0"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
