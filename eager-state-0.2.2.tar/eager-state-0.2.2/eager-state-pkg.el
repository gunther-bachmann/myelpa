;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eager-state" "0.2.2"
  "Eagerly persist data onto disk."
  '((emacs "29.1")
    (llama "0.5.0"))
  :url "https://github.com/meedstrom/eager-state"
  :commit "53282709833021dfbe8605c9eadaa0fffe5da349"
  :revdesc "0.2.2-0-g532827098330"
  :keywords '("convenience")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
