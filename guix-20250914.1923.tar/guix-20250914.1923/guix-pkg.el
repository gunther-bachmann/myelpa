;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20250914.1923"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4"))
  :url "https://emacs-guix.gitlab.io/website/"
  :commit "324987fb4a3e67c6f0f565b6605b8fce559f60ee"
  :revdesc "324987fb4a3e"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
