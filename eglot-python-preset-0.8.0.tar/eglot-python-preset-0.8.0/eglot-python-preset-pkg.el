;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-python-preset" "0.8.0"
  "Eglot preset for Python."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-python-preset"
  :commit "51dc5a71d70add67d169a11ecd3e4225582d362c"
  :revdesc "51dc5a71d70a"
  :keywords '("python" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
