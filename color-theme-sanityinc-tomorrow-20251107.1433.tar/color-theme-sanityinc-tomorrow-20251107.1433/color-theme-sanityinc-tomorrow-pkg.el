;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-sanityinc-tomorrow" "20251107.1433"
  "A version of Chris Kempson's \"tomorrow\" themes."
  '((emacs "24.1"))
  :url "https://github.com/purcell/color-theme-sanityinc-tomorrow"
  :commit "f3f05e31cd9fd2e99e8d7859a8d46a549fac9537"
  :revdesc "f3f05e31cd9f"
  :keywords '("faces" "themes")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
